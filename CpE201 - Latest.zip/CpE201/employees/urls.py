from django.urls import path

from .views import CustomLoginView, register, logout_view, home_view, goodbye_view

urlpatterns = [
    path('', home_view, name='home'),
    path('login/', CustomLoginView.as_view(), name='login'),  # Using the class-based view
    path('register/', register, name='register'),
    path('logout/', logout_view, name='logout'),
    path('goodbye/', goodbye_view, name='goodbye'),  # Goodbye page after logout or login
]
