from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.views import LoginView
from django.shortcuts import render, redirect
from django.urls import reverse, reverse_lazy
from .forms import CustomUserCreationForm, LoginForm


# Basic index view
def index(request):
    return render(request, 'index.html')


# Function-based login view
def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                if form.cleaned_data.get('remember_me'):
                    request.session.set_expiry(1209600)  # 2 weeks
                else:
                    request.session.set_expiry(0)
                return redirect('goodbye')  # Redirecting to 'goodbye' after login
            else:
                form.add_error(None, 'Invalid username or password.')
    else:
        form = LoginForm()
    return render(request, 'registration/login.html', {'form': form})


# Function-based registration view
def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')  # Redirecting to log in after registration
    else:
        form = CustomUserCreationForm()

    return render(request, 'registration/register.html', {'form': form})


# Function-based logout view
def logout_view(request):
    logout(request)
    return redirect('goodbye')


# Profile view
def profile_view(request):
    return render(request, 'employees/Profile.html')


# Home view
def home_view(request):
    return render(request, 'home.html')


# Goodbye view
def goodbye_view(request):
    return render(request, 'goodbye.html')


# Class-based custom login view (consolidated)
class CustomLoginView(LoginView):
    template_name = 'registration/login.html'
    redirect_authenticated_user = True

    def get_success_url(self):
        # Redirecting to 'goodbye' after successful login
        return reverse_lazy('goodbye')
