from calendar import calendar

from django.apps import AppConfig


class CalendarConfig(AppConfig):
    name = "calendar"
