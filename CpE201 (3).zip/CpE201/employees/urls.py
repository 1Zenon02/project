from django.urls import path
from . import views
from .views import login_view, logout_view, register, profile_view, goodbye_view

urlpatterns = [
    path('', views.home_view, name='home'),
    path('login/', login_view, name='login'),
    path('logout/', logout_view, name='logout'),
    path('register/', register, name='register'),
    path('profile/', profile_view, name='profile'),
    path('goodbye/', goodbye_view, name='goodbye'),
]
